package contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {

    private final Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = new HashMap<>();
    }

    public void addContact(Contact contact) {

        if (contact == null) {
            throw new IllegalArgumentException(
                    "Contact cannot be null.");
        }

        String contactId = contact.getContactId();

        if (contacts.containsKey(contactId)) {
            throw new IllegalArgumentException(
                    "A contact with ID " + contactId + " already exists.");
        }

        contacts.put(contactId, contact);
    }

    public void deleteContact(String contactId) {

        validateContactId(contactId);

        findContact(contactId);

        contacts.remove(contactId);
    }

    public void updateContact(
            String contactId,
            String firstName,
            String lastName,
            String phone,
            String address) {

        validateContactId(contactId);

        Contact contact = findContact(contactId);

        if (firstName != null) {
            contact.setFirstName(firstName);
        }

        if (lastName != null) {
            contact.setLastName(lastName);
        }

        if (phone != null) {
            contact.setPhone(phone);
        }

        if (address != null) {
            contact.setAddress(address);
        }
    }

    public Contact getContact(String contactId) {

        validateContactId(contactId);

        // Keep original behavior so existing tests continue to pass
        return contacts.get(contactId);
    }

    // Helper Methods

    private void validateContactId(String contactId) {

        if (contactId == null || contactId.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Contact ID cannot be null or blank.");
        }
    }

    private Contact findContact(String contactId) {

        Contact contact = contacts.get(contactId);

        if (contact == null) {
            throw new IllegalArgumentException(
                    "No contact was found with ID " + contactId + ".");
        }

        return contact;
    }
}