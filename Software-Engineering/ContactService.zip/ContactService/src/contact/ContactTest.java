package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
    
    @Test
    public void testContactCreation() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("123", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }
    
    @Test
    public void testContactIdValidation() {
        // Test null contact ID
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
        
        // Test contact ID too long
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
    }
    
    @Test
    public void testFirstNameValidation() {
        // Test null first name
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("123", null, "Doe", "1234567890", "123 Main St"));
        
        // Test first name too long
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("123", "JohnathanDoe", "Doe", "1234567890", "123 Main St"));
    }
    
    @Test
    public void testLastNameValidation() {
        // Test null last name
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("123", "John", null, "1234567890", "123 Main St"));
        
        // Test last name too long
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("123", "John", "DoeDoeDoeDoe", "1234567890", "123 Main St"));
    }
    
    @Test
    public void testPhoneValidation() {
        // Test null phone
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("123", "John", "Doe", null, "123 Main St"));
        
        // Test phone not exactly 10 digits
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("123", "John", "Doe", "123456789", "123 Main St"));
        
        // Test phone with non-digits
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("123", "John", "Doe", "123456789a", "123 Main St"));
    }
    
    @Test
    public void testAddressValidation() {
        // Test null address
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("123", "John", "Doe", "1234567890", null));
        
        // Test address too long
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("123", "John", "Doe", "1234567890", "123 Main Street, Apartment 456, City, State"));
    }
    
    @Test
    public void testSetters() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        
        // Test valid updates
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
        
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
        
        contact.setPhone("9876543210");
        assertEquals("9876543210", contact.getPhone());
        
        contact.setAddress("456 Oak Ave");
        assertEquals("456 Oak Ave", contact.getAddress());
        
        // Test invalid updates
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("Smithsonian"));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("123"));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
    }
}