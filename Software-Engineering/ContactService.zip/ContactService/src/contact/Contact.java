package contact;

public class Contact {
	private final String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

	public Contact(String contactId, String firstName, String lastName, String phone, String address) {

		validateRequiredText(contactId, "Contact ID", 10);
		validateRequiredText(firstName, "First name", 10);
		validateRequiredText(lastName, "Last name", 10);
		validatePhone(phone);
		validateRequiredText(address, "Address", 30);

		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}

	// Getters
	public String getContactId() {
		return contactId;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPhone() {
		return phone;
	}

	public String getAddress() {
		return address;
	}

	// Setters for updatable fields
	public void setFirstName(String firstName) {
		validateRequiredText(firstName, "First name", 10);
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		validateRequiredText(lastName, "Last name", 10);
		this.lastName = lastName;
	}

	public void setPhone(String phone) {
		validatePhone(phone);
		this.phone = phone;
	}

	public void setAddress(String address) {
		validateRequiredText(address, "Address", 30);
		this.address = address;
	}

	// Helper Methods

	private static void validateRequiredText(String value, String fieldName, int maximumLength) {
		if (value == null || value.trim().isEmpty()) {
			throw new IllegalArgumentException(fieldName + " cannot be null or blank.");
		}

		if (value.length() > maximumLength) {
			throw new IllegalArgumentException(fieldName + " must be " + maximumLength + " characters or less.");
		}
	}

	private static void validatePhone(String phone) {

		if (phone == null || !phone.matches("\\d{10}")) {
			throw new IllegalArgumentException("Phone number must contain exactly 10 digits.");
		}
	}
}