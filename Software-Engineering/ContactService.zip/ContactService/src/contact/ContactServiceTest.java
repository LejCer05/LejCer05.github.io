package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    
    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        
        service.addContact(contact);
        assertNotNull(service.getContact("123"));
        
        // Test adding duplicate contact
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
        
        // Test adding null contact
        assertThrows(IllegalArgumentException.class, () -> service.addContact(null));
    }
    
    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        
        service.addContact(contact);
        service.deleteContact("123");
        assertNull(service.getContact("123"));
        
        // Test deleting non-existent contact
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }
    
    @Test
    public void testUpdateContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        
        // Update all fields
        service.updateContact("123", "Jane", "Smith", "9876543210", "456 Oak Ave");
        Contact updated = service.getContact("123");
        assertEquals("Jane", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("9876543210", updated.getPhone());
        assertEquals("456 Oak Ave", updated.getAddress());
        
        // Update single field
        service.updateContact("123", "Jill", null, null, null);
        assertEquals("Jill", service.getContact("123").getFirstName());
        assertEquals("Smith", service.getContact("123").getLastName()); // unchanged
        
        // Test updating non-existent contact
        assertThrows(IllegalArgumentException.class, () -> 
            service.updateContact("999", "Fail", "Fail", "0000000000", "Fail"));
        
        // Test invalid updates through service
        assertThrows(IllegalArgumentException.class, () -> 
            service.updateContact("123", null, null, "123", null));
    }
    
    @Test
    public void testGetContact() {
        ContactService service = new ContactService();
        assertNull(service.getContact("123"));
        
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        assertNotNull(service.getContact("123"));
    }
}