from pymongo import MongoClient


class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self):

        # Connection Variables
    
        USER = "aacuser"
        PASS = "YOUR_PASSWORD"      # Replace with your own password 
        PORT = 27017
        DB = "aac"
        COL = "animals"

        # Initialize Connection
        self.client = MongoClient(
            "mongodb://%s:%s@%s:%d" % (USER, PASS, HOST, PORT)
        )

        self.database = self.client[DB]
        self.collection = self.database[COL]

        # Database indexes for commonly searched fields
        self.collection.create_index("breed")
        self.collection.create_index("animal_type")
        self.collection.create_index("sex_upon_outcome")
        self.collection.create_index("age_upon_outcome_in_weeks")

    # -------------------------------------------------
    # Helper Method
    # -------------------------------------------------

    def _validate_dictionary(self, value, field_name):
        """Validate dictionary inputs."""

        if value is None:
            raise ValueError(f"{field_name} cannot be None.")

        if not isinstance(value, dict):
            raise TypeError(f"{field_name} must be a dictionary.")

        return value

    # -------------------------------------------------
    # Create
    # -------------------------------------------------

    def create(self, data):

        self._validate_dictionary(data, "Data")

        if not data:
            raise ValueError("Data cannot be empty.")

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged

        except Exception as error:
            print(f"Create operation failed: {error}")
            return False

    # -------------------------------------------------
    # Read
    # -------------------------------------------------

    def read(self, query=None, limit=0):

        if query is None:
            query = {}

        self._validate_dictionary(query, "Query")

        if not isinstance(limit, int) or limit < 0:
            raise ValueError("Limit must be a non-negative integer.")

        try:

            cursor = self.collection.find(query)

            if limit > 0:
                cursor = cursor.limit(limit)

            return list(cursor)

        except Exception as error:
            print(f"Read operation failed: {error}")
            return []

    # -------------------------------------------------
    # Update
    # -------------------------------------------------

    def update(self, query, new_values):

        self._validate_dictionary(query, "Query")
        self._validate_dictionary(new_values, "New Values")

        if not query:
            raise ValueError("Update query cannot be empty.")

        if not new_values:
            raise ValueError("Update values cannot be empty.")

        try:

            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )

            return {
                "matched_count": result.matched_count,
                "modified_count": result.modified_count
            }

        except Exception as error:
            print(f"Update operation failed: {error}")

            return {
                "matched_count": 0,
                "modified_count": 0
            }

    # -------------------------------------------------
    # Delete
    # -------------------------------------------------

    def delete(self, query):

        self._validate_dictionary(query, "Query")

        if not query:
            raise ValueError("Delete query cannot be empty.")

        try:

            result = self.collection.delete_many(query)

            return {
                "deleted_count": result.deleted_count
            }

        except Exception as error:
            print(f"Delete operation failed: {error}")

            return {
                "deleted_count": 0
            }

    # -------------------------------------------------
    # Sorted Read Enhancement
    # -------------------------------------------------

    def read_sorted(
        self,
        query=None,
        sort_field="name",
        ascending=True,
        limit=500
    ):

        if query is None:
            query = {}

        self._validate_dictionary(query, "Query")

        if not isinstance(sort_field, str):
            raise ValueError("Sort field must be a string.")

        if limit <= 0:
            raise ValueError("Limit must be greater than zero.")

        direction = 1 if ascending else -1

        try:

            cursor = (
                self.collection
                .find(query)
                .sort(sort_field, direction)
                .limit(limit)
            )

            return list(cursor)

        except Exception as error:
            print(f"Sorted read failed: {error}")
            return []

    # -------------------------------------------------
    # Aggregation Enhancement
    # -------------------------------------------------

    def aggregate_by_field(self, field_name, query=None):

        if query is None:
            query = {}

        self._validate_dictionary(query, "Query")

        pipeline = [

            {
                "$match": query
            },

            {
                "$group": {
                    "_id": f"${field_name}",
                    "count": {
                        "$sum": 1
                    }
                }
            },

            {
                "$sort": {
                    "count": -1
                }
            }

        ]

        try:

            return list(
                self.collection.aggregate(pipeline)
            )

        except Exception as error:
            print(f"Aggregation failed: {error}")
            return []