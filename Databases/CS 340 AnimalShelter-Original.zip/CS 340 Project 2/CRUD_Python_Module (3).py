# Example Python Code to Insert a Document 

from bson.objectid import ObjectId
from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'password123'   # replaced with my MongoDB password
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create
    def create(self, data):
        if data is not None and isinstance(data, dict):
            insert_result = self.collection.insert_one(data)
            return True if insert_result.inserted_id else False
        else:
            raise Exception("Nothing to save, data is empty or invalid")

    # Read
    def read(self, query):
        if query is not None and isinstance(query, dict):
            cursor = self.collection.find(query)  # cursor object
            result = list(cursor)  # convert to list
            return result
        else:
            raise Exception("Query parameter is empty or invalid")

    # Update
    def update(self, query, new_values):
        if query and new_values:
            update_result = self.collection.update_many(query, {"$set": new_values})
            return f"{update_result.modified_count} documents updated"
        else:
            raise Exception("Query or update data is empty")

    # Delete
    def delete(self, query):
        if query:
            delete_result = self.collection.delete_many(query)
            return f"{delete_result.deleted_count} documents deleted"
        else:
            raise Exception("Query parameter is empty")